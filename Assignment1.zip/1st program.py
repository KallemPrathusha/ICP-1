#Author:Kallem Prathusha
def string_op():
    try:
        inp_a = str(input("Enter your string here:"))
        if inp_a != '' and inp_a is not None and inp_a.isspace() != True and inp_a.isnumeric() != True:

            output = inp_a[:-2]
            output = output[::-1] #reversal of the string after truncating
            print(output)
            #end of block1
        else:
            print("please enter a valid string")
    except Exception as error:
        print("Error occured {}".format(error))

    number1 = float(input("Enter the first number: "))
    number2 = float(input("Enter the second number: "))

    print("Addition:", number1 + number2)
    print("Subtraction:", number1 - number2)
    print("Multiplication:", number1 * number2)

    if number2 != 0:
        print("Division:", number1 / number2)
    else:
        print("Cannot divide by zero.")
#end of block1
if __name__ == "__main__":
    string_op()