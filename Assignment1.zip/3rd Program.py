def grading():
    try:
        try:
            class_score = int(input("Enter Score:"))
        except ValueError:
            print ("Please enter valid numbers")
            return None
        if class_score != '' and class_score is not None:
            if class_score > 100 or class_score < 0:
                print("please enter a valid score the score is not within the range")
            else:
                if class_score >= 90 and class_score <= 100: #Grade A
                    print("A")
                elif class_score >= 80 and class_score <= 89: #Grade B
                    print("B")
                elif class_score >= 70 and class_score <= 79: #Grade C
                    print("c")
                elif class_score >= 60 and class_score <= 69: #Grade D
                    print("D")
                else:
                    print("F") #Grade F

        else:
            print("please enter a valid number")
    except Exception as error:
        print("Error occured {}".format(error))
#end of block
if __name__ == "__main__":
    grading()