#Author: Kallem Prathusha
def str_op():
    try:
        input_str = input("Please enter the string :")
        if input_str != '' and input_str is not None and input_str.isspace() != True and input_str.isnumeric() != True:
            input_str = input_str.replace('python','pythons')
            print(input_str)
        else:
            print("String entered is incorrect")
    except Exception as error:
        print("Error occured{}".format(error))
#end of block
if __name__ == "__main__":
    str_op()